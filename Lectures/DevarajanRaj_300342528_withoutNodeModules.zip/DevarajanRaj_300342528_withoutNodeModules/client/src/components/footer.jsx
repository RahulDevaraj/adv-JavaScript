const Footer = () => {
  return (
    <footer>
      <p>Rahul Devarajan Raj</p>
    </footer>
  );
};

export default Footer;
