const Header = () => {
  return (
    <header>
      <h1>It's Festive season. Lets have some fun!!</h1>
      <h4>Real Food Recipes anyone can make or bake.</h4>
    </header>
  );
};

export default Header;
