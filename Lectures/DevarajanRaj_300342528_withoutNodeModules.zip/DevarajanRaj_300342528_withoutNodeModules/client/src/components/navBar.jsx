import { Link } from "react-router-dom";
const NavBar = () => {
  return (
    <ul>
      <li>
        <Link to="/">Top Recipes</Link>
      </li>
    </ul>
  );
};

export default NavBar;
